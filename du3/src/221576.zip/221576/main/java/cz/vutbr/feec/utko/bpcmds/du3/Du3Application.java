package cz.vutbr.feec.utko.bpcmds.du3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Du3Application {

	public static void main(String[] args) {

		SpringApplication.run(Du3Application.class, args);
	}

}
